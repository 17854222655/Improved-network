class Unet_SEA_ResnetGenerator(nn.Module):

    def __init__(self, input_nc, output_nc, ngf=64, norm_layer=nn.BatchNorm2d, use_dropout=False, n_blocks=6,
                 padding_type='reflect'):
        assert (n_blocks >= 0)
        super(Unet_SEA_ResnetGenerator, self).__init__()
        if type(norm_layer) == functools.partial:
            use_bias = norm_layer.func == nn.InstanceNorm2d
        else:
            use_bias = norm_layer == nn.InstanceNorm2d
        self.pad = nn.ReflectionPad2d(3)
        self.Down_conv1 = nn.Conv2d(input_nc, ngf, kernel_size=7, padding=0, bias=use_bias)  # 下采样第一层
        self.conv_norm = norm_layer(input_nc)
        self.relu = nn.ReLU(True)
        self.Down_conv2 = nn.Conv2d(ngf, ngf * 2, kernel_size=3, stride=2, padding=1, bias=use_bias)  # 下采样第二层
        self.SA = Self_Attention_no_connect(ngf * 2, 'relu')
        self.Down_conv3 = nn.Conv2d(ngf * 2, ngf * 4, kernel_size=3, stride=2, padding=1, bias=use_bias)  # 下采样第三层
        self.Sa_block_3 = SEA_Block_3(ngf * 4, padding_type=padding_type, norm_layer=norm_layer,
                                      use_dropout=use_dropout, use_bias=use_bias)
        self.Sa_resnetblock_1 = SEA_ResnetBlock_1(ngf * 4, padding_type=padding_type, norm_layer=norm_layer,
                                                  use_dropout=use_dropout, use_bias=use_bias)
        self.resnet = ResnetBlock(ngf * 4, padding_type=padding_type, norm_layer=norm_layer, use_dropout=use_dropout,
                                  use_bias=use_bias)
        self.Up_conv1 = nn.ConvTranspose2d(ngf * 4 * 2, ngf * 2, kernel_size=3, stride=2, padding=1, output_padding=1,
                                           bias=use_bias)
        self.Up_conv2 = nn.ConvTranspose2d(ngf * 2 * 2, ngf, kernel_size=3, stride=2, padding=1, output_padding=1,
                                           bias=use_bias)
        self.Up_conv3 = nn.Conv2d(ngf * 2, output_nc, kernel_size=7, padding=0)
        self.tan = nn.Tanh()

    def forward(self, x):
        x1 = self.relu(self.conv_norm(self.Down_conv1(self.pad(x))))
        x2 = self.relu(self.conv_norm(self.Down_conv2(x1)))
        x3 = self.relu(self.conv_norm(self.Down_conv3(x2)))
        x4 = self.resnet(x3)
        x = torch.cat([x4, x3], 1)
        x = self.relu(self.conv_norm(self.Up_conv1(x)))
        x = torch.cat([x, x2], 1)
        x = self.relu(self.conv_norm(self.Up_conv2(x)))
        x = torch.cat([x, x1], 1)
        x = self.tan(self.Up_conv3(self.pad(x)))
        return x